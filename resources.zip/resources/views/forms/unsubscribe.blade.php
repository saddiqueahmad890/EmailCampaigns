<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unsubscribe Successful</title>
</head>
<body>
    <h1 style="text-align: center;">Unsubscribe Successful</h1>
    <p style="text-align: center;">The email address <strong>{{ $email }}</strong> has been unsubscribed from this campaign.</p>
</body>
</html>
