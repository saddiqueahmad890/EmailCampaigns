<div class="modal fade" id="scheduleEmailModal" tabindex="-1" role="dialog" aria-labelledby="scheduleEmailModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <form action="<?php echo e(route('email-campaign.schedule')); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="id" value="<?php echo e($campaign->id); ?>">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Schedule Email</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <label for="scheduled_date">Select Date to Send:</label>
          <input type="date" name="scheduled_date" class="form-control" required min="<?php echo e(now()->toDateString()); ?>">
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Schedule</button>
        </div>
      </div>
    </form>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\my-laravel-app\resources\views/modals/schedule-email-modal.blade.php ENDPATH**/ ?>