<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h3 class="fw-bold mb-3">Manage Campaigns</h3>
    <ul class="breadcrumbs mb-3">
        <li class="nav-home">
            <a href="/">
                <i class="icon-home"></i>
            </a>
        </li>
        <li class="separator">
            <i class="icon-arrow-right"></i>
        </li>
        <li class="nav-item">
            <a href="#">Manage Campaigns</a>
        </li>
        <li class="separator">
            <i class="icon-arrow-right"></i>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('campaign')); ?>">View Campaigns</a>
        </li>
    </ul>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="table-responsive">
            <table class="table">
                <thead class="thead-light">
                    <tr>
                     
                        <th>Campaign Name</th>
                        <th>Subject Line</th>
                        <th>No of Email Addresses</th>
                        <th>Email Template Filename</th>
                        <th>CSV Filename</th>
                        <th>View Emails</th>
                        <th>View HTML</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($campaigns) > 0): ?>
                    <?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                       
                        <td>
                            <a href="<?php echo e(route('campaign.details', ['id' => $item->id])); ?>">
                                <?php echo e($item->campaign_name); ?>

                            </a>
                        </td>
                        <td><?php echo e($item->subject_line); ?></td>
                        <td><?php echo e($item->email_count); ?></td>
                        <td 
                        style="
                            max-width: 70px;
                            overflow: hidden;
                            text-overflow: ellipsis;
                            white-space: nowrap;
                        "
                        >
                            <?php echo e($item->email_body); ?>

                        </td>
                        <td 
                        style="
                            max-width: 100px;
                            overflow: hidden;
                            text-overflow: ellipsis;
                            white-space: nowrap;
                        ">
                            <?php echo e($item->csv_file); ?>

                        </td>
                        <td>
                            <button type="button" class="btn btn-success px-2 py-1 py-xl-2 px-xl-3" data-toggle="modal" \
                                data-target="#emailModal-<?php echo e($item->id); ?>">
                                View
                            </button>
                        </td>
                        <td>
                            <button type="button" class="btn btn-success px-2 py-1 py-xl-2 px-xl-3" data-toggle="modal"
                                data-target="#htmlModal-<?php echo e($item->id); ?>">
                                View
                            </button>
                        </td>
                        <td>
                            <div class="d-flex justify-content-start align-items-center gap-2">
                                <i class="far fa-edit p-3" style="cursor: pointer" data-toggle="modal"
                                    data-target="#editCampaingModal-<?php echo e($item->id); ?>"></i>
                                <form method="POST" action="<?php echo e(route('delete-campaign', ['id' => $item->id])); ?>"
                                    id="deleteForm-<?php echo e($item->id); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
    
                                    <i class="fas fa-trash p-3" style="cursor: pointer"
                                        onclick="confirmDelete(<?php echo e($item->id); ?>)"></i>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr>
                        <td colspan="8">No data found</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php if(count($campaigns) > 0): ?>
<?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- Edit Campaign Modal -->
<div class="modal fade" id="editCampaingModal-<?php echo e($item->id); ?>" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Edit Campaign</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('edit-campaign' , ['id' => $item->id])); ?>" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-12">
                            <div class="form-group">
                                <input type="hidden" data-campaign-id="<?php echo e($item->id); ?>" value="<?php echo e($item->id); ?>">
                                <label for="campaign">New Campaign Name</label>
                                <input type="text" class="form-control" data-campaign-name="<?php echo e($item->id); ?>" 
                                       name="campaign_name" value="<?php echo e($item->campaign_name); ?>" 
                                       placeholder="Enter new campaign name" />
                                <p data-error-content="<?php echo e($item->id); ?>" class="text-danger --bs-danger"></p>
                            </div>

                            <div class="form-group">
                                <label for="leads-csv">Add New Leads to CSV
                                </label>
                                <br>
                                <input type="file" accept=".csv" name="leads_csv" class="form-control-file" id="leads-csv" value="<?php echo e($item->leads_csv); ?>"/>
                            </div>

                            <div class="form-group">
                                <label for="index-number">Index Column Number</label>
                                <input type="number" class="form-control" name="column_number" id="index-number"
                                    placeholder="Enter Number"  />
                            </div>

                            <div class="form-group">
                                <label for="subject">New Subject Line</label>
                                <input type="text" class="form-control" id="subject" value="<?php echo e($item->subject_line); ?>"
                                    name="subject_line" placeholder="Enter Subject Line" />
                            </div>

                            <div class="form-group">
                                <label for="email-file">New Email Template (HTML)
                                </label>
                                <br>
                                <input type="file" name="email_body" class="form-control-file" id="email-file" accept=".html" />
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success">Submit</button>
                    <button class="btn btn-danger" data-dismiss="modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Email -->
<div class="modal fade" id="emailModal-<?php echo e($item->id); ?>" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle"><?php echo e($item->campaign_name); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead class="thead-light">
                            <tr>
                                <th>#</th>
                                <th>Email</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($item->emails) > 0): ?>
                            <?php $__currentLoopData = $item->emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><?php echo e($email); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr>
                                <td colspan="2">No data found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="htmlModal-<?php echo e($item->id); ?>" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle"><?php echo e($item->campaign_name); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <iframe src="<?php echo e(route('campaign.html', $item->id)); ?>" width="100%" height="400px"></iframe>
                
            </div>
            <div class="modal-footer">
                <button class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('[data-campaign-name]').forEach((inputElement) => {
            inputElement.addEventListener('keyup', function () {
                const campaignId = inputElement.getAttribute('data-campaign-name');
                const campaignName = inputElement.value;
                const errorDisplay = document.querySelector(`[data-error-content="${campaignId}"]`);

                fetch('/check-campaign', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                    },
                    body: JSON.stringify({ campaign_name: campaignName, id: campaignId })
                })
                .then(response => response.json())
                .then(data => {
                    // Display error if campaign name is taken
                    if (data.exists) {
                        errorDisplay.textContent = 'Campaign Name is already taken.';
                    } else {
                        errorDisplay.textContent = '';
                    }
                })
                .catch(error => console.error('Error:', error));
            });
        });
    });
</script>


<script>
    function confirmDelete(Id) {
          if (confirm("Are you sure you want to delete this campaign?")) {
              document.getElementById('deleteForm-' + Id).submit();
          }
      }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\my-laravel-app\resources\views/forms/campaign.blade.php ENDPATH**/ ?>