<?php echo $__env->make('modals.schedule-email-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div>

    <div class="card-title pt-3 fs-4">Send Email (<?php echo e(count($campaign->emails)); ?>)</div>

    <div style="height:fit-content; max-height: 210px; overflow-y:scroll">
        <div class="table-responsive">
            <table class="table">
                <thead class="thead-light">
                    <tr>
                        <th>#</th>
                        <th>Email</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($campaign->emails) > 0): ?>
                    <?php $__currentLoopData = $campaign->emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key + 1); ?></td>
                        <td><?php echo e($email); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr>
                        <td colspan="2">No data found</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card-title pt-3 fs-4">Email Preview</div>
    <div>
        <iframe src="<?php echo e(route('campaign.html', $campaign->id)); ?>" width="100%" height="400px"></iframe>
    </div>

    <div class="card-title pt-3 fs-4">Subject</div>
    <div class="card-title p-3 bg-gray1 rounded-1"><?php echo e($campaign->subject_line); ?></div>

    <div class="card-title py-3 fs-4">Send Test Email</div>
    <div class="">
        <button
            type="button"
            class="btn btn-secondary"
            data-toggle="modal"
            data-target="#sendEmailModal">
            Send Email
        </button>
    </div>

    <div class="modal fade" id="sendEmailModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Send Test Email</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('email.test')); ?>" method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <input type="hidden" name="id" value="<?php echo e($campaign->id); ?>">
                                    <label for="email">Enter Email Address</label>
                                    <br>
                                    <input type="email" name="email" id="email" class="form-control" placeholder="Enter Email">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">Submit</button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <div class="card-title py-3 fs-4">Send Campaign Email</div>
    <?php if($hasHistory): ?>
    <button
        type="button"
        class="btn btn-success"
        data-toggle="modal"
        data-target="#campaignAlert">
        Send Campaign Email
    </button>
    <!-- Schedule Email Button -->
    <button
        type="button"
        class="btn btn-info ml-2"
        data-toggle="modal"
        data-target="#scheduleEmailModal">
        Schedule Email
    </button>
    <?php else: ?>
    <form action="<?php echo e(route('send.emails')); ?>" method="POST" enctype="multipart/form-data" class="">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($campaign->id); ?>">
        <button type="submit" class="btn btn-success">Send Campaign Email</button>
        <!-- Schedule Email Button -->
        <button
            type="button"
            class="btn btn-info ml-2"
            data-toggle="modal"
            data-target="#scheduleEmailModal">
            Schedule Email
        </button>
    </form>
    <?php endif; ?>


    <div class="modal fade" id="campaignAlert" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Attenzione</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('send.emails')); ?>" method="POST" enctype="multipart/form-data" class="">
                    <div class="modal-body">
                        <p>
                            <strong><?php echo e(count($sentEmails)); ?></strong> contatti sono stati già contattati in questa campagna, sei sicuro di volerli ricontattare tutti?
                            Ci sono <strong><?php echo e(count($emailsToSend)); ?></strong> contatti in questa campagna che non sono stati contattati
                        </p>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($campaign->id); ?>">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="send_option" id="exampleRadios1" value="2" checked>
                            <label class="form-check-label" for="exampleRadios1">
                                Ricontatta tutti
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="send_option" id="exampleRadios2" value="1">
                            <label class="form-check-label" for="exampleRadios2">
                                Contatta i nuovi
                            </label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-danger" data-dismiss="modal">Chiudi</button>
                        <button type="submit" class="btn btn-success">Send Campaign Email</button>
                    </div>
                </form>

            </div>
        </div>
    </div>

</div><?php /**PATH C:\xampp\htdocs\my-laravel-app\resources\views/partials/details.blade.php ENDPATH**/ ?>