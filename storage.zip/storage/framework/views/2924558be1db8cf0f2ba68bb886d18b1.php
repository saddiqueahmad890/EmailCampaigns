<!DOCTYPE html>
<html lang="en">

<head>

  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="icon" href="<?php echo e(asset('assets/img/kaiadmin/favicon.ico')); ?>" type="image/x-icon" />


    <!-- Fonts and icons -->
    <script src="<?php echo e(asset('assets/js/plugin/webfont/webfont.min.js')); ?>"></script>
    <script>
      WebFont.load({
        google: {
          families: ["Public Sans:300,400,500,600,700"]
        },
        custom: {
          families: [
            "Font Awesome 5 Solid",
            "Font Awesome 5 Regular",
            "Font Awesome 5 Brands",
            "simple-line-icons"
          ],
          urls: ["<?php echo e(asset('assets/css/fonts.min.css')); ?>"]
        },
        active: function() {
          sessionStorage.fonts = true;
        }
      });
    </script>

    <!-- CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/kaiadmin.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/demo.css')); ?>">

    <?php echo $__env->yieldContent('styles'); ?>
  </head>

<body>
  <div class="wrapper">
    <?php echo $__env->make('admin.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="container">
      <div class="page-inner">

        <!-- 
        <?php if(Request::path() !== '/' && Request::path() !== 'exclusion-list'): ?>
        <div class="page-header">
          <h3 class="fw-bold mb-3">Dashboard</h3>
          <ul class="breadcrumbs mb-3">
            <li class="nav-home">
              <a href="#"><i class="icon-home"></i></a>
            </li>
            <li class="separator"><i class="icon-arrow-right"></i></li>
            <li class="nav-item"><a href="#"><?php echo $__env->yieldContent('manage'); ?></a></li>
            <li class="separator"><i class="icon-arrow-right"></i></li>
            <li class="nav-item"><a href="#"><?php echo $__env->yieldContent('compaign'); ?></a></li>
          </ul>
        </div>
        <?php endif; ?> -->

        <div class="container">
          <?php echo $__env->make('inc.messages', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
          <?php echo $__env->yieldContent('content'); ?>
        </div>

        <?php echo $__env->make('admin.layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

      </div>
    </div>
  </div>

  <!-- JS Files -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="<?php echo e(asset('assets/js/core/jquery-3.7.1.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/core/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/core/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/plugin/chart.js/chart.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/plugin/chart-circle/circles.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/plugin/datatables/datatables.min.js')); ?>"></script>
  <!-- <script src="<?php echo e(asset('assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js')); ?>"></script> -->
  <script src="<?php echo e(asset('assets/js/plugin/jsvectormap/jsvectormap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/plugin/jsvectormap/world.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/plugin/sweetalert/sweetalert.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/kaiadmin.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/setting-demo.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/demo.js')); ?>"></script>

  <script>
    // Example charts
    $("#lineChart").sparkline([102, 109, 120, 99, 110, 105, 115], {
      type: "line",
      height: "70",
      width: "100%",
      lineWidth: "2",
      lineColor: "#177dff",
      fillColor: "rgba(23, 125, 255, 0.14)"
    });

    $("#lineChart2").sparkline([99, 125, 122, 105, 110, 124, 115], {
      type: "line",
      height: "70",
      width: "100%",
      lineWidth: "2",
      lineColor: "#f3545d",
      fillColor: "rgba(243, 84, 93, .14)"
    });

    $("#lineChart3").sparkline([105, 103, 123, 100, 95, 105, 115], {
      type: "line",
      height: "70",
      width: "100%",
      lineWidth: "2",
      lineColor: "#ffa534",
      fillColor: "rgba(255, 165, 52, .14)"
    });
  </script>

  <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\my-laravel-app\resources\views/admin/master.blade.php ENDPATH**/ ?>