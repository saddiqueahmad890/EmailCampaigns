<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h3 class="fw-bold mb-3">Manage Campaigns</h3>
    <ul class="breadcrumbs mb-3">
        <li class="nav-home">
            <a href="/">
                <i class="icon-home"></i>
            </a>
        </li>
        <li class="separator">
            <i class="icon-arrow-right"></i>
        </li>
        <li class="nav-item">
            <a href="#">Manage Campaigns</a>
        </li>
        <li class="separator">
            <i class="icon-arrow-right"></i>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('forms.send-email')); ?>">Send Email</a>
        </li>
    </ul>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <div class="card-title">Send Email</div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 col-lg-4">
                        <div class="">
                            <p>Emails left for today</p>
                            
                            <?php if(count($smtpAccounts) > 0): ?>
                                <?php $__currentLoopData = $smtpAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p>SMTP Acc # <?php echo e($key + 1); ?> = <?php echo e($account->emails_remaining_today); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <p>No SMTP Acc found</p>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="leads-csv">Select Campaign
                            </label>
                            <br>
                            <select name="campaign_id" id="campaign-id" class="form-select">
                                <option value="">Select Campaign</option>
                                <?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php echo e(session('campaign_id') == $item->id ? "selected" : ""); ?>><?php echo e($item->campaign_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="pt-4" id="campaign-details"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        let campaignNameInput = document.getElementById('campaign-id');
        
        function fetchCampaign (){
            const campaignDetailsDiv = document.getElementById('campaign-details');
            const campaignId = campaignNameInput.value;

            if (campaignId) {
                fetch('/fetch-campaign', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                    },
                    body: JSON.stringify({ campaign_id: campaignId })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        console.log("success" , data);
                        campaignDetailsDiv.innerHTML = data.result;
                    } else {
                        console.log("Error" , data);
                        campaignDetailsDiv.innerHTML = ``;
                    }
                })
                .catch(error => console.error('Error:', error));
            }
        }

        fetchCampaign();

        campaignNameInput.addEventListener('change', fetchCampaign);
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\my-laravel-app\resources\views/forms/send-email.blade.php ENDPATH**/ ?>