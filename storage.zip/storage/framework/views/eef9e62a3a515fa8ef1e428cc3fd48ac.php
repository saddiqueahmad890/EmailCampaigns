<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h3 class="fw-bold mb-3">Manage Campaigns</h3>
    <ul class="breadcrumbs mb-3">
        <li class="nav-home">
            <a href="/">
                <i class="icon-home"></i>
            </a>
        </li>
        <li class="separator">
            <i class="icon-arrow-right"></i>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('campaign')); ?>">View Campaigns</a>
        </li>
        <li class="separator">
            <i class="icon-arrow-right"></i>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('campaign.details', ['id' => $campaign->id])); ?>">Campaign Details</a>
        </li>
    </ul>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="table-responsive">
            <table class="table">
                <thead class="thead-light">
                    <tr>
                        <th>Campaign Nddame</th>
                        <th>Subject Line</th>
                        <!-- <th>No of Email Addresses Reached</th> -->
                        <th>Date of Sending</th>
                        <th>No of Viewed Emails</th>
                        <th>View Sending Details</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($histories)> 0): ?>
                    <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($campaign->campaign_name); ?></td>
                        <td><?php echo e($campaign->subject_line); ?></td>
                        <!-- <td><?php echo e($history->email_count); ?></td> -->
                        <td><?php echo e($history->date_sent ? $history->date_sent : "-"); ?></td>
                        <td><?php echo e($history->email_open_count); ?></td>
                        <td>
                            <button
                                type="button"
                                class="btn btn-success px-2 py-1 py-xl-2 px-xl-3"
                                data-toggle="modal"
                                data-target="#emailModal-<?php echo e($history->id); ?>">
                                View
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr>
                        <td colspan="6">No data found</td>
                    </tr>
                    <?php endif; ?>
                    <?php if(count($test_emails) > 0): ?>
                    <?php $__currentLoopData = $test_emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <p class="m-0">
                                <span class="badge badge-secondary">Test</span>
                                <?php echo e($campaign->campaign_name); ?>

                            </p>
                        </td>
                        <td><?php echo e($campaign->subject_line); ?></td>
                        <td><?php echo e(1); ?></td>
                        <td><?php echo e($item->date_sent); ?></td>
                        <td>
                            <?php if($item->is_opened == '1'): ?>
                            <i class="fa fa-check text-success"></i>
                            <?php else: ?>
                            <i class="fa fa-times text-danger"></i>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($item->email); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        
</div>
</div>

<?php if(count($histories)> 0): ?>
<?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- Email -->
<div class="modal fade modal-lg" id="emailModal-<?php echo e($history->id); ?>" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle"><?php echo e($campaign->campaign_name); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table ">
                        <thead class="thead-light">
                            <tr>
                                <th>#</th>
                                <th>Email</th>
                                <th>Email Sent</th>
                                <th>Email Clicked</th>
                                <th>Email Opened</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($history->email_details) > 0): ?>
                            <?php $__currentLoopData = $history->email_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $emailDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><?php echo e($emailDetail['email']); ?></td>
                                <td>
                                    <?php if($emailDetail['sent_status'] == '1'): ?>
                                    <i class="fa fa-check text-success"></i>
                                    <?php else: ?>
                                    <i class="fa fa-times text-danger"></i>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($emailDetail['click_status'] == '1'): ?>
                                    <i class="fa fa-check text-success"></i>
                                    <?php else: ?>
                                    <i class="fa fa-times text-danger"></i>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($emailDetail['opened_status'] == '1'): ?>
                                    <i class="fa fa-check text-success"></i>
                                    <?php else: ?>
                                    <i class="fa fa-times text-danger"></i>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr>
                                <td colspan="2">No data found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer d-flex flex-wrap ">
                <a href="<?php echo e(route('campaign.download.sent', $history->id)); ?>" class="btn btn-success">Download Sent Emails</a>
                <a href="<?php echo e(route('campaign.download.clicked', $history->id)); ?>" class="btn btn-success">Download Clicked Emails</a>
                <a href="<?php echo e(route('campaign.download.opened', $history->id)); ?>" class="btn btn-primary">Download Opened Emails</a>
                <a href="<?php echo e(route('campaign.download.unopened', $history->id)); ?>" class="btn btn-warning">Download Unopened Emails</a>
                <button class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>

        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\my-laravel-app\resources\views/forms/details.blade.php ENDPATH**/ ?>